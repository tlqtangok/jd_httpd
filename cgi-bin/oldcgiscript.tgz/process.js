#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

// Read POST data from stdin
let body = '';
process.stdin.setEncoding('utf8');

process.stdin.on('data', chunk => {
    body += chunk;
});

process.stdin.on('end', () => {
    // Parse the form data
    const params = new URLSearchParams(body);
    const inputstr = params.get('inputstr') || '';
    
    // Path to save the file
    const filePath = '/usr/local/apache2/htdocs/inputstr.txt';
    
    try {
        // Save to disk
        fs.writeFileSync(filePath, inputstr + '\n', { flag: 'a' });
        
        // Send CGI response
        console.log('Content-Type: text/plain\n');
        console.log(`String "${inputstr}" saved to ${filePath} at ${new Date().toISOString()}`);
    } catch (error) {
        console.log('Status: 500 Internal Server Error\n');
        console.log('Content-Type: text/plain\n');
        console.log('Error saving file: ' + error.message);
    }
});
