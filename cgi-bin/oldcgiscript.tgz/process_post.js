#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

// Read POST data from stdin
let body = '';
process.stdin.setEncoding('utf8');

process.stdin.on('data', chunk => {
    body += chunk;
});

process.stdin.on('end', () => {
    try {
        // Parse JSON payload
        const data = JSON.parse(body);
        const inputstr = data.inputstr || '';
        
        // Path to save the file
        const filePath = '/usr/local/apache2/htdocs/inputstr_post.txt';
        
        // Save to disk
        fs.writeFileSync(filePath, inputstr + '\n', { flag: 'a' });
        
        // Send CGI response
        console.log('Content-Type: text/plain\n');
        console.log(`JSON POST: String "${inputstr}" saved to ${filePath} at ${new Date().toISOString()}`);
    } catch (error) {
        console.log('Status: 500 Internal Server Error\n');
        console.log('Content-Type: text/plain\n');
        console.log('Error: ' + error.message);
    }
});
